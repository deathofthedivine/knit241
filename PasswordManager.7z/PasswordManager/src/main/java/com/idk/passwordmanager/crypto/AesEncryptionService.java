package com.idk.passwordmanager.crypto;

import com.idk.passwordmanager.security.MasterPasswordHolder;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.security.*;
import java.security.spec.KeySpec;
import java.util.Arrays;
import java.util.Base64;

public class AesEncryptionService implements EncryptionService {
    private static final String ALGO = "AES/CBC/PKCS5Padding";
    private static final String KEY_FACTORY_ALGO = "PBKDF2WithHmacSHA256";
    private static final int IV_LENGTH = 16;
    private static final int SALT_LENGTH = 16;

    private final MasterPasswordHolder masterPasswordHolder;
    private final SecureRandom secureRandom = new SecureRandom();

    public AesEncryptionService(MasterPasswordHolder holder) {
        this.masterPasswordHolder = holder;
    }

    private SecretKey getKey(char[] password, byte[] salt) throws Exception {
        SecretKeyFactory factory = SecretKeyFactory.getInstance(KEY_FACTORY_ALGO);
        KeySpec spec = new PBEKeySpec(password, salt, 65536, 256);
        return new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "AES");
    }

    @Override
    public String encrypt(String raw) {
        try {
            byte[] salt = new byte[SALT_LENGTH];
            secureRandom.nextBytes(salt);

            SecretKey secretKey = getKey(masterPasswordHolder.get(), salt);

            byte[] iv = new byte[IV_LENGTH];
            secureRandom.nextBytes(iv);
            IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

            Cipher cipher = Cipher.getInstance(ALGO);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivParameterSpec);
            byte[] encrypted = cipher.doFinal(raw.getBytes());

            byte[] output = new byte[SALT_LENGTH + IV_LENGTH + encrypted.length];
            System.arraycopy(salt, 0, output, 0, SALT_LENGTH);
            System.arraycopy(iv, 0, output, SALT_LENGTH, IV_LENGTH);
            System.arraycopy(encrypted, 0, output, SALT_LENGTH + IV_LENGTH, encrypted.length);

            return Base64.getEncoder().encodeToString(output);
        } catch (Exception e) {
            throw new RuntimeException("Encryption failed", e);
        }
    }

    @Override
    public String decrypt(String encryptedString) {
        try {
            byte[] data = Base64.getDecoder().decode(encryptedString);

            byte[] salt = Arrays.copyOfRange(data, 0, SALT_LENGTH);
            byte[] iv = Arrays.copyOfRange(data, SALT_LENGTH, SALT_LENGTH + IV_LENGTH);
            byte[] encrypted = Arrays.copyOfRange(data, SALT_LENGTH + IV_LENGTH, data.length);

            SecretKey secretKey = getKey(masterPasswordHolder.get(), salt);

            Cipher cipher = Cipher.getInstance(ALGO);
            cipher.init(Cipher.DECRYPT_MODE, secretKey, new IvParameterSpec(iv));
            return new String(cipher.doFinal(encrypted));
        } catch (Exception e) {
            throw new RuntimeException("Decryption failed", e);
        }
    }
}