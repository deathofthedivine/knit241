package com.idk.passwordmanager.repository;

import com.idk.passwordmanager.model.PasswordEntry;
import java.util.*;

public interface PasswordRepository {
    void add(PasswordEntry e);
    void delete(String site);
    PasswordEntry get(String site);
    List<PasswordEntry> getAll();
    void setAll(List<PasswordEntry> entries);
}
