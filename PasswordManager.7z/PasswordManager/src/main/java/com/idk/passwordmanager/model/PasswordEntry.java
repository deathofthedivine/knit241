package com.idk.passwordmanager.model;

public class PasswordEntry {
    public String site;
    public String login;
    public String encryptedPassword;

    public PasswordEntry() {}
    public PasswordEntry(String site, String login, String encryptedPassword) {
        this.site = site;
        this.login = login;
        this.encryptedPassword = encryptedPassword;
    }
}
