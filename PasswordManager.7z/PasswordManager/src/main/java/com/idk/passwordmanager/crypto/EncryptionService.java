package com.idk.passwordmanager.crypto;

public interface EncryptionService {
    String encrypt(String raw);
    String decrypt(String enc);
}
