package com.idk.passwordmanager.storage;

import com.fasterxml.jackson.core.type.TypeReference;
import com.idk.passwordmanager.crypto.EncryptionService;
import com.idk.passwordmanager.model.PasswordEntry;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.*;

public class EncryptedFileStorage {
    private final File storageFile = new File("master_vault.json");
    private final ObjectMapper mapper = new ObjectMapper();
    private final EncryptionService encryptionService;

    public EncryptedFileStorage(EncryptionService encryptionService) {
        this.encryptionService = encryptionService;
    }

    public List<PasswordEntry> load(String userId) {
        Map<String, String> vault = loadVault();
        String encryptedData = vault.get(userId);

        if (encryptedData == null || encryptedData.isEmpty()) {
            return new ArrayList<>();
        }

        try {
            String json = encryptionService.decrypt(encryptedData);
            return mapper.readValue(json, new TypeReference<>() {});
        } catch (Exception e) {
            throw new RuntimeException("Failed to decrypt data. Master password may be incorrect.", e);
        }
    }

    public void save(String userId, List<PasswordEntry> entries) {
        Map<String, String> vault = loadVault();
        try {
            String json = mapper.writeValueAsString(entries);
            String encryptedData = encryptionService.encrypt(json);
            vault.put(userId, encryptedData);

            Files.write(storageFile.toPath(), mapper.writerWithDefaultPrettyPrinter().writeValueAsBytes(vault));
        } catch (Exception e) {
            throw new RuntimeException("Failed to save data.", e);
        }
    }

    private Map<String, String> loadVault() {
        if (!storageFile.exists()) {
            return new HashMap<>();
        }
        try {
            byte[] fileBytes = Files.readAllBytes(storageFile.toPath());
            if (fileBytes.length == 0) {
                return new HashMap<>();
            }
            return mapper.readValue(fileBytes, new TypeReference<>() {});
        } catch (IOException e) {
            return new HashMap<>();
        }
    }
}