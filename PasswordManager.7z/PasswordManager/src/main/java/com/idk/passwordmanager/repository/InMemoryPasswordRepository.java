package com.idk.passwordmanager.repository;

import com.idk.passwordmanager.model.PasswordEntry;
import java.util.*;

public class InMemoryPasswordRepository implements PasswordRepository {
    private final Map<String, PasswordEntry> m = new HashMap<>();

    public void add(PasswordEntry e) { m.put(e.site, e); }
    public void delete(String site) { m.remove(site); }
    public PasswordEntry get(String site) { return m.get(site); }
    public List<PasswordEntry> getAll() { return new ArrayList<>(m.values()); }
    public void setAll(List<PasswordEntry> l) {
        m.clear();
        for (PasswordEntry e : l) m.put(e.site, e);
    }
}
