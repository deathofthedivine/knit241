package com.idk.passwordmanager;

import com.idk.passwordmanager.config.AppConfig;
import com.idk.passwordmanager.security.MasterPasswordHolder;
import com.idk.passwordmanager.security.UserIdentifier;
import com.idk.passwordmanager.service.PasswordService;
import com.idk.passwordmanager.storage.EncryptedFileStorage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.Arrays;
import java.util.Scanner;

public class App {
    private static final Logger log = LoggerFactory.getLogger(App.class);

    public static void main(String[] args) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
        MasterPasswordHolder masterPasswordHolder = ctx.getBean(MasterPasswordHolder.class);
        PasswordService svc = ctx.getBean(PasswordService.class);
        EncryptedFileStorage store = ctx.getBean(EncryptedFileStorage.class);

        Runtime.getRuntime().addShutdownHook(new Thread(ctx::close));

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Password Manager ---");
            System.out.print("Введите мастер-пароль (или 'exit' для выхода): ");
            char[] masterPassword;
            if (System.console() != null) {
                masterPassword = System.console().readPassword();
            } else {
                masterPassword = scanner.nextLine().toCharArray();
            }

            if (new String(masterPassword).equalsIgnoreCase("exit")) {
                break;
            }

            masterPasswordHolder.setPassword(masterPassword);
            String userId = UserIdentifier.generate(masterPassword);

            try {
                svc.load(store.load(userId));
                log.info("Успешный вход для пользователя с ID: {}", userId);
                System.out.println("Хранилище успешно загружено. Добро пожаловать!");
            } catch (Exception e) {
                log.error("Не удалось войти для пользователя {}: {}", userId, e.getMessage());
                System.out.println("ОШИБКА: Не удалось расшифровать хранилище. Проверьте мастер-пароль.");
                masterPasswordHolder.clear();
                Arrays.fill(masterPassword, '\0');
                continue;
            }

            boolean loggedIn = true;
            while (loggedIn) {
                System.out.print(userId.substring(0, 6) + "@vault > ");
                String line = scanner.nextLine();
                String[] cmd = line.split(" ", 2);

                try {
                    switch (cmd[0]) {
                        case "add" -> {
                            System.out.print("site: "); String site = scanner.nextLine();
                            System.out.print("login: "); String login = scanner.nextLine();
                            System.out.print("password: "); String pwd = scanner.nextLine();
                            svc.add(site, login, pwd);
                            store.save(userId, svc.getAll());
                            System.out.println("Запись добавлена.");
                        }
                        case "list" -> svc.list();
                        case "copy" -> {
                            if (cmd.length < 2) { System.out.println("Укажите сайт: copy <site>"); continue; }
                            svc.copy(cmd[1]);
                            System.out.println("Пароль для '" + cmd[1] + "' скопирован в буфер обмена на 30 секунд.");
                        }
                        case "delete" -> {
                            if (cmd.length < 2) { System.out.println("Укажите сайт: delete <site>"); continue; }
                            svc.delete(cmd[1]);
                            store.save(userId, svc.getAll());
                            System.out.println("Запись для '" + cmd[1] + "' удалена.");
                        }
                        case "logout" -> {
                            loggedIn = false;
                            System.out.println("Выход из текущего хранилища...");
                        }
                        case "exit" -> {
                            System.out.println("Завершение работы...");
                            System.exit(0);
                        }
                        default -> System.out.println("Команды: add, list, copy, delete, logout, exit");
                    }
                } catch (Exception e) {
                    log.error("Ошибка при выполнении команды '{}'", line, e);
                    System.out.println("Произошла ошибка: " + e.getMessage());
                }
            }
            masterPasswordHolder.clear();
            Arrays.fill(masterPassword, '\0');
        }

        System.out.println("Работа приложения завершена.");
    }
}