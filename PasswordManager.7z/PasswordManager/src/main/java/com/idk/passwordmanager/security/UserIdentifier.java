package com.idk.passwordmanager.security;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

public class UserIdentifier {

    private static final byte[] IDENTIFIER_SALT = "a-very-fixed-salt-for-user-id".getBytes();
    private static final String ALGORITHM = "PBKDF2WithHmacSHA256";

    public static String generate(char[] masterPassword) {
        try {
            KeySpec spec = new PBEKeySpec(masterPassword, IDENTIFIER_SALT, 65536, 128); // 128-bit hash is enough for an ID
            SecretKeyFactory factory = SecretKeyFactory.getInstance(ALGORITHM);
            byte[] hash = factory.generateSecret(spec).getEncoded();
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new RuntimeException("Could not generate user identifier", e);
        }
    }
}