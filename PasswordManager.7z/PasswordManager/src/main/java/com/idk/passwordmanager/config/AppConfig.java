package com.idk.passwordmanager.config;

import com.idk.passwordmanager.clipboard.*;
import com.idk.passwordmanager.crypto.*;
import com.idk.passwordmanager.repository.*;
import com.idk.passwordmanager.security.*;
import com.idk.passwordmanager.service.*;
import com.idk.passwordmanager.storage.*;
import org.springframework.context.annotation.*;

@Configuration
public class AppConfig {
    @Bean
    public MasterPasswordHolder masterPasswordHolder() {
        return new MasterPasswordHolder();
    }

    @Bean
    public EncryptionService enc(MasterPasswordHolder m) {
        return new AesEncryptionService(m);
    }

    @Bean
    public ClipboardService cb() {
        return new SystemClipboardService();
    }

    @Bean
    public PasswordRepository repo() {
        return new InMemoryPasswordRepository();
    }

    @Bean
    public PasswordService svc(PasswordRepository r, EncryptionService e, ClipboardService c) {
        return new PasswordService(r, e, c);
    }

    @Bean
    public EncryptedFileStorage storage(EncryptionService e) {
        return new EncryptedFileStorage(e);
    }
}