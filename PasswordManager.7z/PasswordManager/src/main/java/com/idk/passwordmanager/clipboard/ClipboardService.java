package com.idk.passwordmanager.clipboard;

public interface ClipboardService {
    void copy(String text);
}