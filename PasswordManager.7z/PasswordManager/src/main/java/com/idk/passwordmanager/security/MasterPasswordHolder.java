package com.idk.passwordmanager.security;

import java.util.Arrays;

public class MasterPasswordHolder {
    private char[] password;

    public MasterPasswordHolder() {
        this.password = null;
    }

    public void setPassword(char[] password) {
        this.password = password;
    }

    public char[] get() {
        return password;
    }

    public void clear() {
        if (password != null) {
            Arrays.fill(password, '\0');
            password = null;
        }
    }
}