package com.idk.passwordmanager.clipboard;

import java.awt.*;
import java.awt.datatransfer.*;
import java.util.concurrent.*;

public class SystemClipboardService implements ClipboardService {
    public void copy(String text) {
        Toolkit.getDefaultToolkit().getSystemClipboard()
                .setContents(new StringSelection(text), null);
        ScheduledExecutorService ex = Executors.newSingleThreadScheduledExecutor();
        ex.schedule(() -> {
            Toolkit.getDefaultToolkit().getSystemClipboard()
                    .setContents(new StringSelection(""), null);
            ex.shutdown();
        }, 30, TimeUnit.SECONDS);
    }
}
