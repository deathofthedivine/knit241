package com.idk.passwordmanager.service;

import com.idk.passwordmanager.model.PasswordEntry;
import com.idk.passwordmanager.repository.PasswordRepository;
import com.idk.passwordmanager.crypto.EncryptionService;
import com.idk.passwordmanager.clipboard.ClipboardService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PasswordService {
    private final PasswordRepository repo;
    private final EncryptionService enc;
    private final ClipboardService cb;
    private final Logger log = LoggerFactory.getLogger(PasswordService.class);

    public PasswordService(PasswordRepository r, EncryptionService e, ClipboardService c) {
        repo = r; enc = e; cb = c;
    }

    public void add(String site, String login, String pwd) {
        repo.add(new PasswordEntry(site, login, enc.encrypt(pwd)));
        log.info("add {}", site);
    }

    public void delete(String site) {
        repo.delete(site);
        log.info("delete {}", site);
    }

    public void copy(String site) {
        var e = repo.get(site);
        if (e == null) throw new RuntimeException("not found");
        cb.copy(enc.decrypt(e.encryptedPassword));
        log.info("copy {}", site);
    }

    public void list() {
        for (var e : repo.getAll())
            System.out.println(e.site + " - " + e.login);
    }

    public java.util.List<PasswordEntry> getAll() {
        return repo.getAll();
    }

    public void load(java.util.List<PasswordEntry> l) {
        repo.setAll(l);
    }
}
