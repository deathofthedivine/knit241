package com.example.demo.controller;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@Slf4j
public class HelloController {

    @GetMapping("/hello")
    public String sayHello() {
        log.info("Был вызван GET-запрос /api/hello");
        return "Привет, мир!";
    }

    @PostMapping("/echo")
    public Message echo(@RequestBody Message input) {
        log.info("Был вызван POST-запрос /api/echo с телом: {}", input.getText());
        return input;
    }

    @Data
    @AllArgsConstructor
    static class Message {
        private String text;
    }
}